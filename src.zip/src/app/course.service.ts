import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Course } from './course';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class CourseService {

  private baseUrl = 'http://localhost:8080/api/courses'

  constructor(private httpClient: HttpClient) { }

  getCoursesList():Observable<Course[]> {
    return this.httpClient.get<Course[]>(`${this.baseUrl}`);
  }
  createCourse(course: Course): Observable<Object>{
    return this.httpClient.post(`${this.baseUrl}`,course);
  }
}
