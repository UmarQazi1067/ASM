export class Course {
    courseId: number;
    courseName: string;
    courseDescription: string;
    coursePrice: string;
    courseDuration: string;
}
