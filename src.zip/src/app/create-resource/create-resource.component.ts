import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-resource',
  templateUrl: './create-resource.component.html',
  styleUrls: ['./create-resource.component.css']
})
export class CreateResourceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
