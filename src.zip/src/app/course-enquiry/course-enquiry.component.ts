import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-enquiry',
  templateUrl: './course-enquiry.component.html',
  styleUrls: ['./course-enquiry.component.css']
})
export class CourseEnquiryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
